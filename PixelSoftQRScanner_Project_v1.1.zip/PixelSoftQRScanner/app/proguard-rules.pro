# Keep the Android activity entry point.
-keep class com.pixelsoft.qrscanner.MainActivity { *; }
