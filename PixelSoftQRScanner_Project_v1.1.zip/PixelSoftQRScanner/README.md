# PixelSoft QR Scanner

Aplikasi Android QR scanner berbranding PixelSoft.

## Fitur
- Scan QR Code melalui kamera
- Hasil scan langsung tampil
- Salin hasil scan
- Buka hasil sebagai link
- Riwayat hingga 30 hasil terakhir
- Flash/senter kamera
- Logo PixelSoft terpasang pada aplikasi

## Cara membuat APK
1. Buka folder ini di Android Studio terbaru.
2. Biarkan Gradle melakukan sinkronisasi dan mengunduh dependency.
3. Pilih **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android: Android 6.0 (API 23).
