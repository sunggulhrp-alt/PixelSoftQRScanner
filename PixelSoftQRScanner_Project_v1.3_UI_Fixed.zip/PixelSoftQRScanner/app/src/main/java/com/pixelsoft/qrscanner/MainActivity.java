package com.pixelsoft.qrscanner;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    private PreviewView previewView;
    private TextView resultText;
    private ImageButton flashButton, galleryButton, clearHistoryButton;
    private TextView navScan, navHistory, navSettings, navAbout;
    private View scanScreen, historyScreen;
    private LinearLayout historyList;
    private TextView historyCount;
    private EditText historySearch;
    private Camera camera;
    private ExecutorService cameraExecutor;
    private BarcodeScanner scanner;
    private final AtomicBoolean processing = new AtomicBoolean(false);
    private String lastResult = "";
    private SharedPreferences prefs;
    private final List<HistoryEntry> history = new ArrayList<>();

    private final ActivityResultLauncher<String> cameraPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) startCamera();
                else Toast.makeText(this, "Izin kamera diperlukan untuk scan.", Toast.LENGTH_LONG).show();
            });

    private final ActivityResultLauncher<String> galleryPicker =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) scanFromGallery(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.previewView);
        resultText = findViewById(R.id.resultText);
        flashButton = findViewById(R.id.flashButton);
        galleryButton = findViewById(R.id.galleryButton);
        clearHistoryButton = findViewById(R.id.clearHistoryButton);
        scanScreen = findViewById(R.id.scanScreen);
        historyScreen = findViewById(R.id.historyScreen);
        historyList = findViewById(R.id.historyList);
        historyCount = findViewById(R.id.historyCount);
        historySearch = findViewById(R.id.historySearch);
        navScan = findViewById(R.id.navScan);
        navHistory = findViewById(R.id.navHistory);
        navSettings = findViewById(R.id.navSettings);
        navAbout = findViewById(R.id.navAbout);

        cameraExecutor = Executors.newSingleThreadExecutor();
        prefs = getSharedPreferences("scan_history", MODE_PRIVATE);
        loadHistory();

        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                        Barcode.FORMAT_QR_CODE,
                        Barcode.FORMAT_AZTEC,
                        Barcode.FORMAT_DATA_MATRIX,
                        Barcode.FORMAT_PDF417,
                        Barcode.FORMAT_CODE_128,
                        Barcode.FORMAT_CODE_39,
                        Barcode.FORMAT_CODE_93,
                        Barcode.FORMAT_CODABAR,
                        Barcode.FORMAT_EAN_13,
                        Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_ITF,
                        Barcode.FORMAT_UPC_A,
                        Barcode.FORMAT_UPC_E)
                .build();
        scanner = BarcodeScanning.getClient(options);

        galleryButton.setOnClickListener(v -> galleryPicker.launch("image/*"));
        flashButton.setOnClickListener(v -> toggleFlash());
        clearHistoryButton.setOnClickListener(v -> clearHistory());
        navScan.setOnClickListener(v -> showScanScreen());
        navHistory.setOnClickListener(v -> showHistoryScreen());
        navSettings.setOnClickListener(v -> showSettings());
        navAbout.setOnClickListener(v -> showAbout());

        historySearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { renderHistory(s.toString()); }
            @Override public void afterTextChanged(Editable s) { }
        });

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA);
        }
    }

    @androidx.annotation.OptIn(markerClass = androidx.camera.core.ExperimentalGetImage.class)
    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                ImageAnalysis analysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                analysis.setAnalyzer(cameraExecutor, imageProxy -> {
                    if (processing.get()) {
                        imageProxy.close();
                        return;
                    }
                    android.media.Image mediaImage = imageProxy.getImage();
                    if (mediaImage == null) {
                        imageProxy.close();
                        return;
                    }
                    processing.set(true);
                    InputImage image = InputImage.fromMediaImage(
                            mediaImage, imageProxy.getImageInfo().getRotationDegrees());
                    scanner.process(image)
                            .addOnSuccessListener(barcodes -> {
                                for (Barcode barcode : barcodes) {
                                    String value = barcode.getRawValue();
                                    if (value != null && !value.isEmpty()) {
                                        runOnUiThread(() -> showResult(value));
                                        break;
                                    }
                                }
                            })
                            .addOnCompleteListener(task -> {
                                processing.set(false);
                                imageProxy.close();
                            });
                });

                provider.unbindAll();
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
            } catch (Exception e) {
                Toast.makeText(this, "Kamera gagal dimulai.", Toast.LENGTH_LONG).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void scanFromGallery(Uri uri) {
        try {
            InputImage image = InputImage.fromFilePath(this, uri);
            scanner.process(image)
                    .addOnSuccessListener(barcodes -> {
                        String found = null;
                        for (Barcode barcode : barcodes) {
                            String value = barcode.getRawValue();
                            if (value != null && !value.isEmpty()) {
                                found = value;
                                break;
                            }
                        }
                        if (found != null) {
                            showResult(found);
                            Toast.makeText(this, "Barcode berhasil dipindai dari galeri", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "Barcode / QR tidak ditemukan pada gambar.", Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Gagal membaca gambar.", Toast.LENGTH_LONG).show());
        } catch (Exception e) {
            Toast.makeText(this, "Gambar tidak dapat dibaca.", Toast.LENGTH_LONG).show();
        }
    }

    private void showResult(String value) {
        if (value.equals(lastResult)) return;
        lastResult = value;
        resultText.setText(value);
        saveHistory(value);
        Toast.makeText(this, "Berhasil dipindai", Toast.LENGTH_SHORT).show();
    }

    private void copyResult() {
        if (lastResult.isEmpty()) {
            Toast.makeText(this, "Belum ada hasil scan.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Barcode Result", lastResult));
        Toast.makeText(this, "Hasil disalin.", Toast.LENGTH_SHORT).show();
    }

    private void openResult() {
        if (lastResult.isEmpty()) {
            Toast.makeText(this, "Belum ada hasil scan.", Toast.LENGTH_SHORT).show();
            return;
        }
        String url = lastResult;
        if (!url.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*$")) url = "https://" + url;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "Hasil scan bukan link yang valid.", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleFlash() {
        if (camera == null || !camera.getCameraInfo().hasFlashUnit()) {
            Toast.makeText(this, "Flash tidak tersedia di kamera ini.", Toast.LENGTH_SHORT).show();
            return;
        }
        Integer torch = camera.getCameraInfo().getTorchState().getValue();
        boolean on = torch == null || torch != androidx.camera.core.TorchState.ON;
        camera.getCameraControl().enableTorch(on);
    }

    private void saveHistory(String value) {
        history.removeIf(item -> item.value.equals(value));
        history.add(0, new HistoryEntry(value, System.currentTimeMillis()));
        while (history.size() > 30) history.remove(history.size() - 1);
        persistHistory();
    }

    private void loadHistory() {
        history.clear();
        String raw = prefs.getString("items_json", "");
        try {
            if (!raw.isEmpty()) {
                JSONArray array = new JSONArray(raw);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject obj = array.getJSONObject(i);
                    history.add(new HistoryEntry(obj.optString("value"), obj.optLong("time", 0)));
                }
                return;
            }
        } catch (Exception ignored) { }

        String old = prefs.getString("items", "");
        if (!old.isEmpty()) {
            String[] parts = old.split("\\|");
            for (String part : parts) {
                if (!part.trim().isEmpty()) history.add(new HistoryEntry(part.trim(), 0));
            }
            while (history.size() > 30) history.remove(history.size() - 1);
            persistHistory();
        }
    }

    private void persistHistory() {
        JSONArray array = new JSONArray();
        for (HistoryEntry item : history) {
            JSONObject obj = new JSONObject();
            try {
                obj.put("value", item.value);
                obj.put("time", item.time);
                array.put(obj);
            } catch (Exception ignored) { }
        }
        prefs.edit().putString("items_json", array.toString()).apply();
    }

    private void clearHistory() {
        if (history.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("Hapus riwayat?")
                .setMessage("Semua riwayat scan akan dihapus.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus", (d, w) -> {
                    history.clear();
                    prefs.edit().remove("items_json").remove("items").apply();
                    renderHistory("");
                }).show();
    }

    private void showScanScreen() {
        scanScreen.setVisibility(View.VISIBLE);
        historyScreen.setVisibility(View.GONE);
        navScan.setBackgroundResource(R.drawable.bg_nav_selected);
        navScan.setTextColor(ContextCompat.getColor(this, R.color.pixel_orange));
        navHistory.setBackgroundColor(Color.TRANSPARENT);
        navHistory.setTextColor(ContextCompat.getColor(this, R.color.pixel_muted));
    }

    private void showHistoryScreen() {
        scanScreen.setVisibility(View.GONE);
        historyScreen.setVisibility(View.VISIBLE);
        navHistory.setBackgroundResource(R.drawable.bg_nav_selected);
        navHistory.setTextColor(ContextCompat.getColor(this, R.color.pixel_orange));
        navScan.setBackgroundColor(Color.TRANSPARENT);
        navScan.setTextColor(ContextCompat.getColor(this, R.color.pixel_muted));
        renderHistory(historySearch.getText().toString());
    }

    private void renderHistory(String query) {
        historyList.removeAllViews();
        historyCount.setText(history.size() + " hasil");
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        for (HistoryEntry item : history) {
            if (!q.isEmpty() && !item.value.toLowerCase(Locale.ROOT).contains(q)) continue;
            historyList.addView(createHistoryCard(item));
        }
        if (historyList.getChildCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("Belum ada riwayat yang cocok.");
            empty.setTextColor(ContextCompat.getColor(this, R.color.pixel_muted));
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(20, 50, 20, 50);
            historyList.addView(empty);
        }
    }

    private View createHistoryCard(HistoryEntry item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(10), dp(10), dp(10));
        card.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, dp(76));
        cardParams.bottomMargin = dp(8);
        card.setLayoutParams(cardParams);

        ImageView icon = new ImageView(this);
        icon.setPadding(dp(10), dp(10), dp(10), dp(10));
        icon.setBackgroundResource(R.drawable.bg_soft_blue);
        icon.setImageResource(iconFor(item.value));
        card.addView(icon, new LinearLayout.LayoutParams(dp(52), dp(52)));

        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setGravity(Gravity.CENTER_VERTICAL);
        text.setPadding(dp(12), 0, dp(6), 0);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, -1, 1);
        card.addView(text, textParams);

        TextView value = new TextView(this);
        value.setText(item.value);
        value.setTextColor(ContextCompat.getColor(this, R.color.pixel_dark));
        value.setTextSize(14);
        value.setMaxLines(2);
        value.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.addView(value);

        TextView time = new TextView(this);
        time.setText(formatTime(item.time));
        time.setTextColor(ContextCompat.getColor(this, R.color.pixel_muted));
        time.setTextSize(12);
        text.addView(time);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextColor(ContextCompat.getColor(this, R.color.pixel_muted));
        arrow.setTextSize(28);
        card.addView(arrow, new LinearLayout.LayoutParams(dp(26), -1));

        card.setOnClickListener(v -> {
            lastResult = item.value;
            resultText.setText(item.value);
            showScanScreen();
        });
        return card;
    }

    private int iconFor(String value) {
        String v = value.toLowerCase(Locale.ROOT);
        if (v.startsWith("wifi:")) return R.drawable.ic_wifi;
        if (v.startsWith("mailto:")) return R.drawable.ic_text;
        if (v.startsWith("http://") || v.startsWith("https://")) return R.drawable.ic_link;
        return R.drawable.ic_barcode;
    }

    private String formatTime(long time) {
        if (time <= 0) return "Riwayat sebelumnya";
        long now = System.currentTimeMillis();
        String pattern = new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date(time));
        String today = new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date(now));
        String timeText = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(time));
        if (pattern.equals(today)) return "Hari ini · " + timeText;
        return new SimpleDateFormat("dd MMM · HH:mm", Locale.getDefault()).format(new Date(time));
    }

    private void showSettings() {
        new AlertDialog.Builder(this)
                .setTitle("Pengaturan")
                .setMessage("PixelSoft QR Scanner\n\n• Pemindaian kamera dan galeri aktif\n• Riwayat maksimal 30 hasil\n• Dukungan barcode 1D/2D dan QR Code")
                .setPositiveButton("OK", null).show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("Tentang PixelSoft QR Scanner")
                .setMessage("Scanner barcode dan QR Code yang ringan, cepat, dan sederhana.\n\nPixelSoft\nScan Simple, Do More\n\nVersi 1.2")
                .setPositiveButton("OK", null).show();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) cameraExecutor.shutdown();
        if (scanner != null) scanner.close();
    }

    private static class HistoryEntry {
        final String value;
        final long time;
        HistoryEntry(String value, long time) {
            this.value = value;
            this.time = time;
        }
    }
}
