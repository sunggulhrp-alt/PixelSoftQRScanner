package com.pixelsoft.qrscanner;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    private PreviewView previewView;
    private TextView resultText;
    private ImageButton flashButton;
    private Button copyButton, openButton, historyButton;
    private Camera camera;
    private ExecutorService cameraExecutor;
    private BarcodeScanner scanner;
    private final AtomicBoolean processing = new AtomicBoolean(false);
    private String lastResult = "";
    private SharedPreferences prefs;

    private final ActivityResultLauncher<String> cameraPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) startCamera();
                else Toast.makeText(this, "Izin kamera diperlukan untuk scan QR.", Toast.LENGTH_LONG).show();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.previewView);
        resultText = findViewById(R.id.resultText);
        flashButton = findViewById(R.id.flashButton);
        copyButton = findViewById(R.id.copyButton);
        openButton = findViewById(R.id.openButton);
        historyButton = findViewById(R.id.historyButton);
        cameraExecutor = Executors.newSingleThreadExecutor();
        prefs = getSharedPreferences("scan_history", MODE_PRIVATE);

        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .build();
        scanner = BarcodeScanning.getClient(options);

        copyButton.setOnClickListener(v -> copyResult());
        openButton.setOnClickListener(v -> openResult());
        historyButton.setOnClickListener(v -> showHistory());
        flashButton.setOnClickListener(v -> toggleFlash());

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA);
        }
    }

    @androidx.annotation.OptIn(markerClass = androidx.camera.core.ExperimentalGetImage.class)
    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                ImageAnalysis analysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                analysis.setAnalyzer(cameraExecutor, imageProxy -> {
                    if (processing.get()) {
                        imageProxy.close();
                        return;
                    }
                    android.media.Image mediaImage = imageProxy.getImage();
                    if (mediaImage == null) {
                        imageProxy.close();
                        return;
                    }
                    processing.set(true);
                    InputImage image = InputImage.fromMediaImage(
                            mediaImage, imageProxy.getImageInfo().getRotationDegrees());
                    scanner.process(image)
                            .addOnSuccessListener(barcodes -> {
                                for (Barcode barcode : barcodes) {
                                    String value = barcode.getRawValue();
                                    if (value != null && !value.isEmpty()) {
                                        runOnUiThread(() -> showResult(value));
                                        break;
                                    }
                                }
                            })
                            .addOnCompleteListener(task -> {
                                processing.set(false);
                                imageProxy.close();
                            });
                });

                provider.unbindAll();
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
            } catch (Exception e) {
                Toast.makeText(this, "Kamera gagal dimulai: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void showResult(String value) {
        if (value.equals(lastResult)) return;
        lastResult = value;
        resultText.setText(value);
        saveHistory(value);
        Toast.makeText(this, "QR berhasil dipindai", Toast.LENGTH_SHORT).show();
    }

    private void copyResult() {
        if (lastResult.isEmpty()) {
            Toast.makeText(this, "Belum ada hasil scan.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("QR Result", lastResult));
        Toast.makeText(this, "Hasil disalin.", Toast.LENGTH_SHORT).show();
    }

    private void openResult() {
        if (lastResult.isEmpty()) {
            Toast.makeText(this, "Belum ada hasil scan.", Toast.LENGTH_SHORT).show();
            return;
        }
        String url = lastResult;
        if (!url.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*$")) url = "https://" + url;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "Hasil scan bukan link yang valid.", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleFlash() {
        if (camera == null || !camera.getCameraInfo().hasFlashUnit()) {
            Toast.makeText(this, "Flash tidak tersedia di kamera ini.", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean on = !camera.getCameraInfo().getTorchState().getValue().equals(1);
        camera.getCameraControl().enableTorch(on);
    }

    private void saveHistory(String value) {
        String old = prefs.getString("items", "");
        String next = value.replace("|", " ") + "|" + old;
        String[] parts = next.split("\\|", -1);
        StringBuilder limited = new StringBuilder();
        int count = 0;
        for (String p : parts) {
            if (p.isEmpty()) continue;
            if (count++ >= 30) break;
            if (limited.length() > 0) limited.append('|');
            limited.append(p);
        }
        prefs.edit().putString("items", limited.toString()).apply();
    }

    private void showHistory() {
        String raw = prefs.getString("items", "");
        if (raw.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Riwayat Scan")
                    .setMessage("Belum ada riwayat.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        String[] items = raw.split("\\|");
        new AlertDialog.Builder(this).setTitle("Riwayat Scan")
                .setItems(items, (dialog, which) -> {
                    lastResult = items[which];
                    resultText.setText(lastResult);
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) cameraExecutor.shutdown();
        if (scanner != null) scanner.close();
    }
}
